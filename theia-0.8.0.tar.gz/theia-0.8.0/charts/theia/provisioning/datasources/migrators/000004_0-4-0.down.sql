--Drop table
DROP tadetector_local
